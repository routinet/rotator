



ALTER TABLE `#__rquote` ADD `user_id` int(11) NOT NULL,
ADD `createdate` datetime DEFAULT NULL;




  
  
  
  
  
  
  
  
  
  INSERT INTO `#__rquote_meta` (`id`, `number_reached`, `date_modified`) VALUES
(2, 1, 1),
(3, 1, 1),
(4, 1, 1),
(5, 1, 1),
(6, 1, 1),
(7, 1, 1),
(8, 1, 1);