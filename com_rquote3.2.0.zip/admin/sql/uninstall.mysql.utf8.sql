-- $Id: uninstall.mysql.utf8.sql 74 2011-6-26 22:04:52Z burke $

#DROP TABLE IF EXISTS `#__rquote`;

#DROP TABLE IF EXISTS `#__rquote_meta`;